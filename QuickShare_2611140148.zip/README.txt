ORBIS WEBSITE — FIRST BUILD
============================

1. Unzip this folder.
2. Open index.html in a browser to preview.
3. Upload the contents of this folder to the root of your GitHub repository.
4. In GitHub: Settings > Pages > Deploy from a branch > main / root.

Included character images:
- Hana Yuri: normal + magical form
- Shirayuki Ren: normal + magical form
- Eden

The other six traveler cards currently use designed initials as placeholders.
To add their original images, put the files in assets/characters/ and update
the corresponding image paths in js/app.js.

This is a static fictional website. Archive locks and access warnings are
immersive UI effects, not real security or authentication.
