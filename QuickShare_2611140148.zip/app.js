const dimensions = [
 {id:'astra',name:'아스트라 폴',type:'A-TYPE',code:'A',status:'SEALED',desc:'대규모 차원 오염으로 세계 대부분이 변질된 봉인 차원. 공간과 중력 법칙이 불안정하다.',terms:['오염 잔향','붕괴 도시','생존 기록'],risk:'출입 금지 · 봉인'},
 {id:'ernes',name:'에르네스 왕국',type:'B-TYPE',code:'B',status:'STABLE',desc:'마법과 마나를 기반으로 발전한 왕국 중심의 판타지 문명.',terms:['왕립 마도원','마나석','마도구','왕실 마법 의회'],risk:'일반 관측 가능'},
 {id:'neon',name:'네온 베일',type:'D-TYPE',code:'D',status:'OBSERVED',desc:'초능력과 거대 기업이 공존하는 네온빛 사이버펑크 대도시.',terms:['픽서 네트워크','능력 등록제','오버로드 증후군','블랙마켓'],risk:'일부 구역 주의'},
 {id:'earth17',name:'지구-17',type:'A-TYPE',code:'A',status:'STABLE',desc:'현실의 지구와 거의 동일한 현대 문명. 차원 은폐 원칙이 적용된다.',terms:['일반 사회','차원 은폐 원칙','미확인 현상 보도'],risk:'은폐 원칙 준수'},
 {id:'chrome',name:'크롬 유니온',type:'C-TYPE',code:'C',status:'STABLE',desc:'인간과 기계 생명체가 공존하는 고도 기계 문명.',terms:['코어 등록 시스템','기억 백업소','기계 지성체 권리법'],risk:'일반 관측 가능'},
 {id:'stella',name:'스텔라 블룸',type:'B-TYPE',code:'B',status:'OBSERVED',desc:'별빛 계약으로 선택받은 마법소녀들이 오염성 존재와 싸우는 세계.',terms:['별의 계약식','별의 사자','별의 조각','별의 축제'],risk:'현지 활동 기록 필요'},
 {id:'void',name:'보이드 머로우',type:'X-TYPE',code:'X',status:'UNKNOWN',desc:'차원 전체가 오염체로 뒤덮이고 세계 법칙이 붕괴한 미확인 붕괴 세계.',terms:['잔존 문명','붕괴 지대','공허 생태계'],risk:'접근 제한 · 관측 불가'}
];
const travelers = [
 {id:'arcadia',name:'아르카디아 벨',alias:'Arcadia Vell',role:'오르비스 총괄자',rank:'ADMINISTRATOR',world:'ORBIS CENTRAL HUB',initial:'A',desc:'오르비스 설립 초기부터 관여한 총괄자. 출신 차원과 나이는 극소수만 알고 있다.',ability:'세계의 경계율(World Decree)을 통해 공간과 차원의 경계를 제어한다.',past:'기원 관련 공식 기록은 제한 권한으로 분류되어 있다.',image:null},
 {id:'kaela',name:'카엘라 린',alias:'Kaela Lynn',role:'공식 파트너 · 3급 베테랑',rank:'RANK 03 / VETERAN',world:'ASTRA FALL',initial:'K',desc:'아스트라 폴의 대규모 오염 사건에서 구조된 생존자. 사용자의 공식 파트너 여행자.',ability:'공간 왜곡 및 조작, 차원 오염 감지.',past:'아스트라 폴 관련 기록 일부 손상. 열람 권한이 제한되어 있다.',image:null},
 {id:'xeon',name:'제온-7',alias:'Xeon-7',role:'기술 연구부 연구원',rank:'RESEARCH STAFF',world:'CHROME UNION',initial:'X',desc:'크롬 유니온 출신 안드로이드. ORBIS 기술 연구부에서 근무한다.',ability:'전술 연산, 패턴 분석, 드론 운용, 에너지 방벽 및 제한적 기계 접속.',past:'기계 지성체 등록 로그로 보관.',image:null},
 {id:'lilia',name:'리리아 에르네스',alias:'Lilia Ernes',role:'궁정 마법사',rank:'EXTERNAL COOPERATOR',world:'ERNES KINGDOM',initial:'L',desc:'에르네스 왕국 귀족 출신 엘프 궁정 마법사.',ability:'마나 편성, 원소 마법, 결계, 구속, 강화 및 칠중 마도진.',past:'일부 금기 마법 자료는 열람 제한.',image:null},
 {id:'saya',name:'사야 카렌',alias:'Saya Karen',role:'프리랜서 해결사(픽서)',rank:'INDEPENDENT',world:'NEON VEIL',initial:'S',desc:'네온 베일 출신 프리랜서 해결사. 현실적이고 직설적인 성격.',ability:'운동량 편향. 움직이는 물체의 방향과 충격, 반동을 전환한다.',past:'개인 신상 및 의뢰인 정보 일부 마스킹.',image:null},
 {id:'luke',name:'루크 하임',alias:'Luke Heim',role:'일반인 · 대학생',rank:'CIVILIAN',world:'EARTH-17',initial:'L',desc:'지구-17 출신의 평범한 대학생. ORBIS와 접촉한 일반인.',ability:'특수 능력 및 전투 능력 없음.',past:'일반 민간인 기록. 별도 제한 사항 없음.',image:null},
 {id:'hana',name:'하나카 유리',alias:'Hanaka Yuri · Stella Lily',role:'신입 마법소녀',rank:'MAGICAL GIRL / ROOKIE',world:'STELLA BLOOM',initial:'H',desc:'스텔라 블룸의 고등학교 2학년. 별꽃의 축복을 받은 신입 마법소녀.',ability:'꽃과 별빛을 활용한 공격·방어·지원 마법.',past:'별의 계약식 이후 활동 기록이 등록되어 있다.',image:'assets/characters/hana-yuri-normal.webp',transformed:'assets/characters/hana-yuri-magical.jpg',form:'normal'},
 {id:'ren',name:'시라유키 렌',alias:'Shirayuki Ren · Stella Noctura',role:'베테랑 마법소녀',rank:'MAGICAL GIRL / VETERAN',world:'STELLA BLOOM',initial:'R',desc:'스텔라 블룸의 고등학교 3학년. 차분하고 무뚝뚝하지만 후배를 돌보는 베테랑 마법소녀.',ability:'월광 지배. 달빛을 이용한 정밀 공격, 은폐 및 구속.',past:'특정 대형 별의 조각 사건 기록 일부 제한.',image:'assets/characters/ren-normal.webp',transformed:'assets/characters/ren-magical.jpg',form:'normal'},
 {id:'eden',name:'에덴',alias:'Eden',role:'보이드 머로우 생존자',rank:'UNRESOLVED SUBJECT',world:'VOID MORROW',initial:'E',desc:'보이드 머로우의 유일한 생존자로 알려진 인물. 심각한 오염의 영향을 받고 있다.',ability:'공허 공간 왜곡, 오염체 동조, 오염 에너지 형상화 및 붕괴 영역.',past:'대상 데이터가 불안정합니다. 상세 기록 열람 불가.',image:'assets/characters/eden.webp',restricted:true}
];
const bulletins=[
 {kind:'notice',label:'NOTICE',title:'중앙 허브 관문 정기 점검 안내',desc:'일부 연결 구역의 이동이 일시 제한됩니다.',date:'2026.11.14'},
 {kind:'alert',label:'INCIDENT',title:'미등록 신호가 관측되었습니다',desc:'발신 차원 및 신호 출처 확인 중. 관련 기록은 ARCHIVE에 임시 보관됩니다.',date:'2026.11.13'},
 {kind:'notice',label:'NOTICE',title:'신규 여행자 등록 기록 갱신',desc:'여행자 데이터베이스 동기화가 완료되었습니다.',date:'2026.11.12'},
 {kind:'mission',label:'MISSION',title:'스텔라 블룸 — 현지 관측 협조',desc:'별의 조각 발생 지역 주변의 변화를 기록할 여행자를 모집합니다.',date:'OPEN'},
 {kind:'mission',label:'MISSION',title:'네온 베일 — 미확인 데이터 회수',desc:'폐쇄된 구역에서 발생한 비정상 신호의 출처를 확인하십시오.',date:'OPEN'}
];
const archives=[
 ['DOC-001','ORBIS 설립 초기 기록','초기 조직 구성 및 최초 관문 기록.','LEVEL 5'],
 ['DOC-014','아스트라 폴 봉인 보고서','대규모 차원 오염 및 봉인 조치 기록.','LEVEL 4'],
 ['DOC-021','총괄자 신원 조사','아르카디아 벨 관련 제한 기록.','LEVEL 6'],
 ['DOC-039','보이드 머로우 생존자 보고서','미확인 생존자 및 관측 데이터.','LEVEL 6']
];
const $=s=>document.querySelector(s);
function showPage(id){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===id));document.querySelectorAll('.nav-link').forEach(b=>b.classList.toggle('active',b.dataset.page===id));$('#mainNav').classList.remove('open');window.scrollTo({top:0,behavior:'smooth'});}
document.querySelectorAll('[data-page]').forEach(el=>el.addEventListener('click',()=>showPage(el.dataset.page)));
$('#menuToggle').addEventListener('click',()=>$('#mainNav').classList.toggle('open'));
function renderDimensions(){ $('#dimensionGrid').innerHTML=dimensions.map(d=>`<article class="dimension-card" data-code="${d.code}" data-id="${d.id}" tabindex="0"><span class="type">${d.type} / ${d.id.toUpperCase()}</span><h3>${d.name}</h3><p>${d.desc}</p><div class="risk">STATUS · ${d.status}　/　${d.risk}</div></article>`).join('');document.querySelectorAll('.dimension-card').forEach(c=>c.addEventListener('click',()=>openDimension(c.dataset.id)));}
function openDimension(id){const d=dimensions.find(x=>x.id===id);$('#modalContent').innerHTML=`<div class="dimension-modal"><p class="eyebrow">${d.type} / DIMENSION DATA</p><h2>${d.name}</h2><p>${d.desc}</p><div class="profile-section"><h4>OBSERVATION STATUS</h4><p>${d.status} · ${d.risk}</p></div><div class="profile-section"><h4>DIMENSION TERMINOLOGY</h4><div class="term-chips">${d.terms.map(t=>`<span>${t}</span>`).join('')}</div></div></div>`;openModal();}
function renderTravelers(filter=''){const list=travelers.filter(t=>(t.name+t.alias+t.world+t.role).toLowerCase().includes(filter.toLowerCase()));$('#travelerCount').textContent=String(list.length).padStart(2,'0')+' RECORDS';$('#travelerGrid').innerHTML=list.map(t=>`<article class="traveler-card ${t.restricted?'unknown':''}" data-id="${t.id}" tabindex="0"><div class="traveler-image">${t.image?`<img src="${t.image}" alt="${t.name}" loading="lazy">`:`<span class="placeholder">${t.initial}</span>`}</div><div class="traveler-info"><span class="rank-label">${t.rank}</span><h3>${t.name}</h3><div class="subname">${t.alias}</div><div class="affiliation">${t.world}</div></div></article>`).join('');document.querySelectorAll('.traveler-card').forEach(c=>c.addEventListener('click',()=>openTraveler(c.dataset.id)));}
function openTraveler(id){const t=travelers.find(x=>x.id===id);let image=t.image;let form=t.form||'normal';const imageHtml=image?`<img class="profile-photo" id="profilePhoto" src="${image}" alt="${t.name}">`:`<div class="profile-photo profile-placeholder" style="height:300px;display:grid;place-items:center;color:var(--cyan);font:60px var(--mono)">${t.initial}</div>`;$('#modalContent').innerHTML=`<div class="profile-layout"><div>${imageHtml}${t.transformed?`<div class="form-switch"><button data-form="normal" class="active">평상시 모습</button><button data-form="transformed">변신 모습</button></div>`:''}</div><div><p class="eyebrow">${t.rank}</p><h2 class="profile-name" id="modalTitle">${t.name}</h2><div class="profile-sub">${t.alias}</div><p class="profile-desc">${t.desc}</p><div class="profile-section"><h4>ROLE / AFFILIATION</h4><p>${t.role}<br>${t.world}</p></div><div class="profile-section"><h4>ABILITY & COMBAT</h4><p>${t.ability}</p></div><div class="profile-section"><h4>BACKGROUND RECORD</h4><p>${t.past}</p></div>${t.restricted?'<div class="archive-warning" style="margin-top:18px"><span>!</span><div><b>DATA INTEGRITY WARNING</b><small>일부 정보가 손상되었거나 확인되지 않았습니다.</small></div></div>':''}</div></div>`;openModal();if(t.transformed){document.querySelectorAll('[data-form]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-form]').forEach(x=>x.classList.toggle('active',x===b));$('#profilePhoto').src=b.dataset.form==='normal'?t.image:t.transformed;}));}}
function openModal(){$('#modalBackdrop').classList.add('open');$('#modalBackdrop').setAttribute('aria-hidden','false');}
function closeModal(){$('#modalBackdrop').classList.remove('open');$('#modalBackdrop').setAttribute('aria-hidden','true');}
$('#modalClose').addEventListener('click',closeModal);$('#modalBackdrop').addEventListener('click',e=>{if(e.target===$('#modalBackdrop'))closeModal();});document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});
$('#travelerSearch').addEventListener('input',e=>renderTravelers(e.target.value));
function renderGates(){$('#gateList').innerHTML=dimensions.map(d=>`<div class="gate-row"><div><b>${d.name}</b><small>${d.type} · ${d.status}</small></div><span class="gate-state ${d.id==='astra'||d.id==='void'?'locked':''}">${d.id==='astra'?'SEALED':d.id==='void'?'NO SIGNAL':'CONNECTED'}</span></div>`).join('');}
function renderBulletins(filter='all'){$('#bulletinList').innerHTML=bulletins.filter(b=>filter==='all'||b.kind===filter).map(b=>`<article class="bulletin-item"><span class="kind">${b.label}</span><div><h3>${b.title}</h3><p>${b.desc}</p></div><time>${b.date}</time></article>`).join('');}
document.querySelectorAll('.bulletin-tabs button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.bulletin-tabs button').forEach(x=>x.classList.toggle('selected',x===b));renderBulletins(b.dataset.filter);}));
function renderArchives(){$('#archiveGrid').innerHTML=archives.map(a=>`<article class="archive-card" tabindex="0"><span class="lock">▣ ${a[3]}</span><span class="doc-code">${a[0]} / CLASSIFIED</span><h3>${a[1]}</h3><p>${a[2]}</p></article>`).join('');document.querySelectorAll('.archive-card').forEach(c=>c.addEventListener('click',()=>{c.style.borderColor='#dc777b';c.querySelector('p').textContent='ACCESS DENIED — AUTHORIZATION REQUIRED';}));}
$('#edenAccess').addEventListener('click',()=>{$('#edenResponse').textContent='ERROR 0xVOID-07 // CONNECTION LOST // TARGET DATA STILL ACTIVE';$('#edenResponse').classList.add('glitch');});
$('#termBtn').addEventListener('click',()=>{showPage('dimensions');openDimension('stella');});
function enterSite(){const screen=$('#introScreen');screen.classList.add('hidden');try{sessionStorage.setItem('orbisVisited','1')}catch(e){}}
$('#enterBtn').addEventListener('click',enterSite);$('#skipIntro').addEventListener('click',enterSite);
try{if(sessionStorage.getItem('orbisVisited'))$('#introScreen').classList.add('hidden')}catch(e){}
renderDimensions();renderTravelers();renderGates();renderBulletins();renderArchives();
